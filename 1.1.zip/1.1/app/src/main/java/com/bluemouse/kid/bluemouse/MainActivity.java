package com.bluemouse.kid.bluemouse;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.View;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import static com.bluemouse.kid.bluemouse.Constants.STATE_CONNECTED;
import static com.bluemouse.kid.bluemouse.Constants.STATE_NONE;
import static com.bluemouse.kid.bluemouse.Statics.mBTservice;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private String Log_Str = "[MainActivity]";
    private FloatingActionButton Search;
    private View main_include;
    private View conn_include;
    private Toolbar toolbar;
    private long exit_time = System.currentTimeMillis();
    private TextView PairName;

    public Handler Main_Handle = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == STATE_NONE){
                Log.i(Log_Str,"Connection Lost!");
                PairName.setText("未连接");
                Toast.makeText(getApplicationContext(),"连接已断开",Toast.LENGTH_LONG).show();
            }
            if (msg.what == STATE_CONNECTED) {
                PairName.setText(mBTservice.mDevice.getName().toString());
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main_include = findViewById(R.id.main_include);
        //PairName = (TextView) findViewById(R.id.PairName);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        PairName = (TextView) headerView.findViewById(R.id.PairName);
        Log.e(Log_Str,"pair name is null ?+"+PairName);
        toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        Search = (FloatingActionButton) findViewById(R.id.fab);
        Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent conn = new Intent(MainActivity.this,BlueConn.class);
                startActivity(conn);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!mBTservice.mAdapter.isEnabled()) { //弹出对话框提示用户是后打开
            Intent enabler = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enabler, 0);
        }
        Log.e(Log_Str,"onStart");
    }
    @Override
    protected void onResume(){
        mBTservice.setHandle(Main_Handle);
        if(mBTservice.getState() == STATE_CONNECTED){
            PairName.setText(mBTservice.mDevice.getName().toString());
        }else{
            PairName.setText("未连接");
        }
        super.onResume();
        Log.e(Log_Str,"onResume");
    }
    @Override
    protected void onDestroy(){
        mBTservice.mAdapter.disable();
        mBTservice.stop();
        Statics.setmBTserviceNull();
        super.onDestroy();
        System.exit(0);
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if(System.currentTimeMillis() - exit_time > 2000){
                Toast.makeText(this,"再按一次退出",Toast.LENGTH_SHORT).show();
                exit_time = System.currentTimeMillis();
            }else{
                super.onBackPressed();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        menu.clear();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.action_settings:
                Intent settings = new Intent(MainActivity.this,Settings.class);
                startActivity(settings);
                break;
            case android.R.id.home:
                Log.e(Log_Str,"click home");
                main_include.setVisibility(View.VISIBLE);
                conn_include.setVisibility(View.GONE);
                toolbar.setTitle(R.string.app_name);
                setSupportActionBar(toolbar);
                break;
            case R.id.scan:
                Log.e(Log_Str,"click scan");
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
