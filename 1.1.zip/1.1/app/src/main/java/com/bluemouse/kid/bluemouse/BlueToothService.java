package com.bluemouse.kid.bluemouse;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import static com.bluemouse.kid.bluemouse.Constants.*;
import static com.bluemouse.kid.bluemouse.Constants.BT_UUID;
import static com.bluemouse.kid.bluemouse.Constants.STATE_CONNECTED;
import static com.bluemouse.kid.bluemouse.Constants.STATE_CONNECTING;
import static com.bluemouse.kid.bluemouse.Constants.STATE_LISTEN;
import static com.bluemouse.kid.bluemouse.Constants.STATE_NONE;
import static com.bluemouse.kid.bluemouse.Constants.SUPER;
import static com.bluemouse.kid.bluemouse.Constants.Super_Continue;
import static com.bluemouse.kid.bluemouse.Constants.Super_Mode_Udisk;
import static com.bluemouse.kid.bluemouse.Constants.Super_Null;

/**
 * Created by Kid on 2016/11/9.
 */

public class BlueToothService {
    private ConnectThread mConnect = null;
    private ConnectedThread mConnected = null;
    private Handler mHandler = null;
    private String out_Log = " [BlueToothService] ";
    public BluetoothAdapter mAdapter = null;
    public BluetoothDevice mDevice = null;
    private UdiskService UdiskHandler = new UdiskService();

    private int mState = STATE_NONE;

    public BlueToothService(){
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mAdapter == null){//表明此手机不支持蓝牙
            return;
        }
        setState(STATE_NONE);
    }

    public synchronized int getState() {
        return mState;
    }

    private synchronized void setState(int state) {
        Log.d(out_Log, "setState() " + mState + " -> " + state);
        mState = state;
        if (mHandler == null){
            Log.e(out_Log,"mHandler is null");
            return;
        }
        mHandler.obtainMessage(mState).sendToTarget();
    }

    public synchronized void setHandle(Handler handler,String Debug) {
        mHandler = handler;
        Log.e(out_Log,Debug+"is Debugging");
    }

    public synchronized void setHandle(Handler handler) {
        mHandler = handler;
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;
            BluetoothSocket tmp = null;
            try {
                tmp = device.createRfcommSocketToServiceRecord(BT_UUID);
            } catch (IOException e) {
                Log.e(out_Log, "create() failed", e);
            }
            mmSocket = tmp;
        }

        public void run() {
            Log.e(out_Log, "BEGIN mConnectThread");
            mAdapter.cancelDiscovery();
            try {
                mmSocket.connect();
            } catch (IOException e) {
                try {
                    mmSocket.close();
                } catch (IOException e2) {
                    Log.e(out_Log, "unable to close() socket during connection failure", e2);
                }
                //connectionFailed();
                return;
            }

            // Reset the ConnectThread because we're done
            synchronized (this) {
                mConnect = null;
            }

            // Start the connected thread
            connected(mmSocket, mmDevice);
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(out_Log, "connect socket failed", e);
            }
        }
    }

    private class ConnectedThread extends Thread{
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            Log.e(out_Log,"Begin Conn!!");
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the BluetoothSocket input and output streams
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(out_Log, "temp sockets not created", e);
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            Log.i(out_Log, "BEGIN mConnectedThread");
            Receive_Handler();
        }

        public void readbyte(byte[] buffer) {
            try {
                // Read from the InputStream
                mmInStream.read(buffer);
                Log.e(out_Log, "Waiting for reading");
            } catch (IOException e) {
                Log.e(out_Log, "disconnected", e);
                setState(STATE_NONE);
            }
        }

        public void writeByte(byte[] buffer) {
            try {

                //mmOutStream();
                //mmInStream.
                mmOutStream.write(buffer);
                //Log.e(out_Log,"Send Write!!");
            } catch (IOException e) {
                Log.e(out_Log, "Exception during write", e);
                setState(STATE_NONE);
            }
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(out_Log, "close() of connect socket failed", e);
            }
        }
    }

    public synchronized void connect(BluetoothDevice device) {
        Log.e(out_Log, "connect to: " + device);
        if (mConnect != null) {
            mConnect.cancel();
            mConnect = null;
        }
        // Cancel any thread attempting to make a connection
        if (mConnected != null) {
            mConnected.cancel();
            mConnected = null;
        }
            // Start the thread to connect with the given device
        mConnect = new ConnectThread(device);
        mConnect.start();

        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket,
                                       BluetoothDevice device) {
        Log.e(out_Log, "connected Begin!");

        // Cancel the thread that completed the connection
        if (mConnect != null) {
            mConnect.cancel();
            mConnect = null;
        }
        if (mConnected != null) {
            mConnected.cancel();
            mConnected = null;
        }
        mConnected = new ConnectedThread(socket);
        mConnected.start();


        mDevice = device;

        setState(STATE_CONNECTED);
    }

    public synchronized void start_listen() {
        Log.d(out_Log, "start");
        if (mConnect != null) {
            mConnect.cancel();
            mConnect = null;
        }

        if (mConnected != null) {
            mConnected.cancel();
            mConnected = null;
        }

        if(mState != STATE_LISTEN){
            setState(STATE_LISTEN);
        }
    }

    public synchronized void stop() {
        Log.d(out_Log, "stop");
        if (mConnect != null) {
            mConnect.cancel();
            mConnect = null;
        }
        if (mConnected != null) {
            mConnected.cancel();
            mConnected = null;
        }

        setState(STATE_NONE);
        mHandler = null;
        mAdapter = null;
    }

    public void writeByte(byte[] out) {
        // Create temporary object
        ConnectedThread r;
        // Synchronize a copy of the ConnectedThread
        synchronized (this) {
            if (mState != STATE_CONNECTED) return;
            r = mConnected;
        }
        r.writeByte(out);
    }

    public void readbyte(byte[] in) {
        // Create temporary object
        ConnectedThread r;
        // Synchronize a copy of the ConnectedThread
        synchronized (this) {
            if (mState != STATE_CONNECTED) return;
            r = mConnected;

        }
        r.readbyte(in);

        //Log.i(out_Log, "recv : " + in[0]);
    }


    public void Receive_Handler(){
        while (mState == STATE_CONNECTED) {
            byte[] i = new byte[3];
            byte[] j = new byte[509];
            readbyte(i);

            if(i[0] == SUPER){
                switch (i[1]){
                    case Super_Mode_Udisk :
                        readbyte(j);
                        //Log.e(out_Log,"Super_Mode_Udisk");
                        String path = new String(j,0,509);
                        path = path.trim();
                        //Log.e(out_Log,"query path = ###"+path+"###");
                        Send_Menu_Byte(UdiskHandler.getMenu(path));

                        break;
                }



            }
        }
    }
    private void Send_Menu_Byte(String[] Menu){
        boolean IsOverFlow = false;
        int BreakPoint = 0;

        do{
            String Menu_Str = "000";
            if (Menu != null) {
                for(int i = BreakPoint;i<Menu.length;i++){
                    if(Menu_Str.getBytes().length+Menu[i].getBytes().length >= 505){
                        BreakPoint = i;
                        IsOverFlow = true;
                        break;
                    }
                    Menu_Str += Menu[i]+"|";
                    IsOverFlow = false;
                }
            }

            for(int tmp = Menu_Str.getBytes().length;tmp<512;tmp++){
                Menu_Str = Menu_Str.concat(" ");
            }

            byte[] Send_Menu_byte = Menu_Str.getBytes();
            Send_Menu_byte[0] = SUPER;
            Send_Menu_byte[1] = Super_Mode_Udisk;
            if(IsOverFlow){
                Send_Menu_byte[2] = Super_Continue;
            }
            if(Menu == null){
                Send_Menu_byte[2] = Super_Null;
            }
            writeByte(Send_Menu_byte);
            Log.e(out_Log,"Menu_Str = ###"+Menu_Str.getBytes().length+"###"+Menu_Str+"###");
        }while(IsOverFlow);
    }









}
